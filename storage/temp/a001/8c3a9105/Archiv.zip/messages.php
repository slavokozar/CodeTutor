<?php

return [

    'marketing-agreement' => '"Souhlasím se zpracováním svých osobních údajů, které jsem poskytnul společnosti XXX, IČ: XXX, se sídlem XXX („Společnost“), touto Společností, a to za účelem zasílání a kontaktování v oblasti marketingových a obchodních sdělení. Tento souhlas uděluji po dobu platnosti této smlouvy se Společností („Smlouva“). Zároveň beru na vědomí, že společnost zpracovává mé osobní údaje za účelem naplnění zákonných povinností (zejména zákona č. 253/2008 Sb.) a za účelem plnění povinností ze Smlouvy.
         Bližší informace o zpracování osobních údajů (včetně způsobu odvolání souhlasu) naleznete <a href=":url">zde</a>."',
];
