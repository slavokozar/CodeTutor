<?php

return [

    'admin' => [

        'registration' => [
            'review' => 'Nová registrace čekající na schválení. <a href=":url">Zobrazit.</a>'
        ]

    ],

    'registration' => [
        'confirm' => 'Potvrďte, prosím, Vaši registraci skrze link zaslán na Váš email'
    ]

];
